﻿using System.Text.Json;
using System.Xml.Serialization;

abstract class MySerializer
{
    public abstract void Write(FurnitureCatalog[] furnitures, string fileName);
    public abstract FurnitureCatalog[] Read(string fileName);
}
class MyJsonSerializer : MySerializer
{
    public override void Write(FurnitureCatalog[] furnitures, string filePath)
    {
        using (FileStream fs = new FileStream(filePath, FileMode.OpenOrCreate))
        {
            JsonSerializer.Serialize(fs, furnitures);
        }
    }
    public override FurnitureCatalog[] Read(string fileName)
    {
        using (FileStream fs = new FileStream(fileName, FileMode.OpenOrCreate))
        {
            return JsonSerializer.Deserialize<FurnitureCatalog[]>(fs);
        }
    }
}

class MyXmlSerializer : MySerializer
{
    public override void Write(FurnitureCatalog[] furnitures, string fileName)
    {
        XmlSerializer xmlSerializer = new XmlSerializer(typeof(FurnitureCatalog[]));
        using (FileStream fs = new FileStream(fileName, FileMode.OpenOrCreate))
        {
            xmlSerializer.Serialize(fs, furnitures);
        }
    }
    public override FurnitureCatalog[] Read(string fileName)
    {
        XmlSerializer xmlSerializer = new XmlSerializer(typeof(FurnitureCatalog[]));
        using (FileStream fs = new FileStream(fileName, FileMode.OpenOrCreate))
        {
            FurnitureCatalog[] t = (FurnitureCatalog[])xmlSerializer.Deserialize(fs);
            return t;
        }
    }
}