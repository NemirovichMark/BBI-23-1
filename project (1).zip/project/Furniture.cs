﻿using System.Text.Json.Serialization;
using System.Xml.Serialization;

[Serializable]
public class FurnitureItem
{
    [XmlAttribute]
    public string Model { get; set; }
    [XmlAttribute]
    public string Brand { get; set; }
    [XmlAttribute]
    public decimal Price { get; set; }

    [JsonConstructor]
    public FurnitureItem(string model, string brand, decimal price)
    {
        Model = model;
        Brand = brand;
        Price = price;
    }

    public FurnitureItem() { }

    public virtual decimal CalculatePrice()
    {
        return Price;
    }

    public override string ToString()
    {
        return $"Модель: {Model}, Бренд: {Brand}, Цена: {Price}";
    }
}

[Serializable]
public class Chair : FurnitureItem
{
    [XmlAttribute]
    public bool HasArmRests { get; set; }
    [XmlAttribute]
    public string Material { get; set; }

    [JsonConstructor]
    public Chair(string model, string brand, decimal price, bool hasArmRests, string material)
        : base(model, brand, price)
    {
        HasArmRests = hasArmRests;
        Material = material;
    }

    public Chair() { }

    public override decimal CalculatePrice()
    {
        decimal finalPrice = Price;
        if (HasArmRests)
        {
            finalPrice += 50;
        }
        if (Material == "Leather")
        {
            finalPrice += 100;
        }
        return finalPrice;
    }

    public override string ToString()
    {
        return $"Модель: {Model}, Бренд: {Brand}, Наличие подлокотников: {HasArmRests}, Материал: {Material}, Окончательная цена: {CalculatePrice()}";
    }
}

[Serializable]
public class Table : FurnitureItem
{
    [XmlAttribute]
    public int NumberOfLegs { get; set; }
    [XmlAttribute]
    public string Shape { get; set; }

    [JsonConstructor]
    public Table(string model, string brand, decimal price, int numberOfLegs, string shape)
        : base(model, brand, price)
    {
        NumberOfLegs = numberOfLegs;
        Shape = shape;
    }

    public Table() { }

    public override decimal CalculatePrice()
    {
        decimal finalPrice = Price;
        if (NumberOfLegs > 4)
        {
            finalPrice += 20 * (NumberOfLegs - 4);
        }
        if (Shape == "Oval")
        {
            finalPrice += 50;
        }
        return finalPrice;
    }

    public override string ToString()
    {
        return $"Модель: {Model}, Бренд: {Brand}, Число ножек: {NumberOfLegs}, Форма: {Shape}, Окончательная цена: {CalculatePrice()}";
    }
}

[Serializable]
public class Sofa : FurnitureItem
{
    [XmlAttribute]
    public int SeatingCapacity { get; set; }
    [XmlAttribute]
    public bool HasRecliner { get; set; }

    [JsonConstructor]
    public Sofa(string model, string brand, decimal price, int seatingCapacity, bool hasRecliner)
        : base(model, brand, price)
    {
        SeatingCapacity = seatingCapacity;
        HasRecliner = hasRecliner;
    }

    public Sofa() { }

    public override decimal CalculatePrice()
    {
        decimal finalPrice = Price;
        finalPrice += 100 * SeatingCapacity;
        if (HasRecliner)
        {
            finalPrice += 200;
        }
        return finalPrice;
    }

    public override string ToString()
    {
        return $"Модель: {Model}, Бренд: {Brand}, Вместимость: {SeatingCapacity}, Наличие кресел: {HasRecliner}, Окончательная цена: {CalculatePrice()}";
    }
}

[Serializable]
public class Bed : FurnitureItem
{
    [XmlAttribute]
    public string Size { get; set; }
    [XmlAttribute]
    public bool HasStorage { get; set; }

    [JsonConstructor]
    public Bed(string model, string brand, decimal price, string size, bool hasStorage)
        : base(model, brand, price)
    {
        Size = size;
        HasStorage = hasStorage;
    }

    public Bed() { }

    public override decimal CalculatePrice()
    {
        decimal finalPrice = Price;
        if (Size == "King")
        {
            finalPrice += 150;
        }
        else if (Size == "Queen")
        {
            finalPrice += 100;
        }
        if (HasStorage)
        {
            finalPrice += 300;
        }
        return finalPrice;
    }

    public override string ToString()
    {
        return $"Модель: {Model}, Бренд: {Brand}, Размер: {Size}, Наличие хранилища: {HasStorage}, Окончательная цена: {CalculatePrice()}";
    }
}

[Serializable]
public class Armchair : Chair
{
    [XmlAttribute]
    public string Coating { get; set; }

    [JsonConstructor]
    public Armchair(string model, string brand, decimal price, bool isErgonomic, string material, string coating)
        : base(model, brand, price, isErgonomic, material)
    {
        Coating = coating;
    }

    public Armchair() { }

    public override decimal CalculatePrice()
    {
        decimal finalPrice = base.CalculatePrice();
        if (Coating == "Velvet")
        {
            finalPrice += 150;
        }
        else if (Coating == "Leather")
        {
            finalPrice += 200;
        }
        return finalPrice;
    }

    public override string ToString()
    {
        return $"Модель: {Model}, Бренд: {Brand}, Наличие подлокотников: {HasArmRests}, Материал: {Material}, Покрытие: {Coating}, Окончательная цена: {CalculatePrice()}";
    }
}

[Serializable]
public class Stool : Chair
{
    [XmlAttribute]
    public int Legs { get; set; }

    [JsonConstructor]
    public Stool(string model, string brand, decimal price, bool isErgonomic, string material, int legs)
        : base(model, brand, price, isErgonomic, material)
    {
        Legs = legs;
    }

    public Stool() { }

    public override decimal CalculatePrice()
    {
        decimal finalPrice = base.CalculatePrice();
        finalPrice += Legs * 10;
        return finalPrice;
    }

    public override string ToString()
    {
        return $"Модель: {Model}, Бренд: {Brand}, Наличие подлокотников: {HasArmRests}, Материал: {Material}, Ножки: {Legs}, Окончательная цена: {CalculatePrice()}";
    }
}


public interface IFurnitureCatalog
{
    void AddItem(FurnitureItem item);
    void RemoveItem(FurnitureItem item);
    void AddItems(FurnitureItem[] items);
    void RemoveItems(FurnitureItem[] items);
    void DisplayCatalog();
}