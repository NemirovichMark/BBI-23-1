﻿public partial class FurnitureCatalog
{
    public void PrioritySort()
    {
        int n = items.Count;

        for (int i = 0; i < n - 1; i++)
        {
            int minIndex = i;
            for (int j = i + 1; j < n; j++)
            {
                if (CompareByBrand(items[j], items[minIndex]) < 0)
                {
                    minIndex = j;
                }
            }
            if (minIndex != i)
            {
                Swap(items, i, minIndex);
            }
        }

        Dictionary<string, List<FurnitureItem>> brandGroups = new Dictionary<string, List<FurnitureItem>>();
        foreach (var item in items)
        {
            if (!brandGroups.ContainsKey(item.Brand))
            {
                brandGroups[item.Brand] = new List<FurnitureItem>();
            }
            brandGroups[item.Brand].Add(item);
        }

        foreach (var brandGroup in brandGroups.Values)
        {
            n = brandGroup.Count;
            for (int i = 0; i < n - 1; i++)
            {
                int minIndex = i;
                for (int j = i + 1; j < n; j++)
                {
                    if (CompareByModel(brandGroup[j], brandGroup[minIndex]) < 0)
                    {
                        minIndex = j;
                    }
                }
                if (minIndex != i)
                {
                    Swap(brandGroup, i, minIndex);
                }
            }
        }

        items.Clear();
        foreach (var brandGroup in brandGroups.Values)
        {
            items.AddRange(brandGroup);
        }
    }

    private int CompareByBrand(FurnitureItem item1, FurnitureItem item2)
    {
        return item1.Brand.CompareTo(item2.Brand);
    }

    private int CompareByModel(FurnitureItem item1, FurnitureItem item2)
    {
        return item1.Model.CompareTo(item2.Model);
    }

    private void Swap(List<FurnitureItem> list, int index1, int index2)
    {
        FurnitureItem temp = list[index1];
        list[index1] = list[index2];
        list[index2] = temp;
    }
}


/*public partial class Shelter
{
    public bool Claustrophobia(Animal animal)
    {
        if (animal.Claustrophobia)
        {
            return true;
        }
        else return false;
    }

    public void CheckClaustrophobia() //запускаем при создании закрытого питомника, чтобы убрать животных с клаустрофобией
    {
        if (!isOutdoorNursery)
        {
            for (int i = 0; i < animals.Count; i++)
            {
                if (Claustrophobia(animals[i]))
                {
                    animals.Remove(animals[i]);
                }
            }
        }
    }
}*/