﻿public partial class FurnitureCatalog : IFurnitureCatalog
{
    public void Sort()
    {
        for (int i = 0; i < items.Count - 1; i++)
        {
            for (int j = 0; j < items.Count - 1 - i; j++)
            {
                if (items[j].CalculatePrice() < items[j + 1].CalculatePrice())
                {
                    var temp = items[j];
                    items[j] = items[j + 1];
                    items[j + 1] = temp;
                }
            }
        }
    }
}
