﻿using System.Text.Json.Serialization;
using System.Xml.Serialization;

[Serializable]
[XmlInclude(typeof(FurnitureItem))]
[XmlInclude(typeof(Chair))]
[XmlInclude(typeof(Table))]
[XmlInclude(typeof(Sofa))]
[XmlInclude(typeof(Bed))]
[XmlInclude(typeof(Armchair))]
[XmlInclude(typeof(Stool))]
public partial class FurnitureCatalog : IFurnitureCatalog
{
    [XmlAttribute]
    public string name;
    [XmlAttribute]
    private List<FurnitureItem> items;

    public string Name
    {
        get => name;
        set => name = value;
    }
    public List<FurnitureItem> Items
    {
        get => items;
        set => items = value;
    }

    public FurnitureCatalog(string name)
    {
        this.name = name;
        items = new List<FurnitureItem>();
    }

    [JsonConstructor]
    public FurnitureCatalog(string name, List<FurnitureItem> items)
    {
        this.name = name;
        this.items = items;
    }

    public FurnitureCatalog() { }

    public void AddItem(FurnitureItem item)
    {
        items.Add(item);
    }

    public void RemoveItem(FurnitureItem item)
    {
        items.Remove(item);
    }

    public void AddItems(FurnitureItem[] items)
    {
        foreach (var item in items)
        {
            AddItem(item);
        }
    }

    public void RemoveItems(FurnitureItem[] items)
    {
        foreach (var item in items)
        {
            RemoveItem(item);
        }
    }

    public void DisplayCatalog()
    {
        if (items.Count == 0)
        {
            Console.WriteLine("Каталог пуст.");
        }
        else
        {
            Console.WriteLine("Каталог мебели:");
            Console.WriteLine($"Название: {Name}");
            foreach (var item in items)
            {
                Console.WriteLine(item.ToString());
            }
        }
    }
}