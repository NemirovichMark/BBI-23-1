﻿class Program
{
    public static void Main()
    {
        FurnitureCatalog[] catalogs = new FurnitureCatalog[] { new FurnitureCatalog("Каталог 1"), new FurnitureCatalog("Каталог 2"), new FurnitureCatalog("Каталог 3") };

        FurnitureItem[] myFurnitures = new FurnitureItem[] {
            new Chair("Comfort Chair", "ChairBrand", 150, true, "Leather"),
            new Table("Dining Table", "TableBrand", 200, 6, "Oval"),
            new Sofa("Family Sofa", "SofaBrand", 300, 3, true),
            new Bed("King Bed", "BedBrand", 400, "King", true),
            new Chair("Executive Chair", "ExecutiveBrand", 200, true, "Fabric"),
            new Table("Coffee Table", "CoffeeBrand", 100, 4, "Round"),
            new Sofa("Luxury Sofa", "LuxuryBrand", 500, 4, true),
            new Bed("Queen Bed", "ComfortSleep", 350, "Queen", false),
            new Chair("Gaming Chair", "GamingBrand", 180, true, "Mesh"),
            new Table("Conference Table", "ConferenceBrand", 500, 8, "Rectangle"),
            new Sofa("Compact Sofa", "CompactBrand", 250, 2, false),
            new Bed("Single Bed", "SoloBrand", 200, "Single", false),
            new Chair("Office Chair", "OfficeBrand", 120, false, "Leather"),
            new Table("End Table", "EndBrand", 50, 3, "Square"),
            new Sofa("Modern Sofa", "ModernBrand", 400, 3, true),
            new Bed("Double Bed", "DoubleDream", 300, "Double", true),
            new Chair("Dining Chair", "DiningBrand", 100, false, "Wood"),
            new Table("Work Table", "WorkBrand", 150, 4, "Rectangle"),
            new Sofa("Classic Sofa", "ClassicBrand", 350, 3, false),
            new Bed("Bunk Bed", "BunkMate", 450, "Bunk", false),
            new Chair("Rocking Chair", "RockingBrand", 160, false, "Fabric"),
            new Table("Patio Table", "PatioBrand", 120, 4, "Hexagon"),
            new Sofa("Outdoor Sofa", "OutdoorBrand", 200, 2, false),
            new Bed("Day Bed", "DayDream", 250, "Day", true),
            new Chair("Recliner Chair", "ReclinerBrand", 250, true, "Leather"),
            new Table("Picnic Table", "PicnicBrand", 180, 6, "Oval"),
            new Sofa("Reclining Sofa", "ReclineBrand", 600, 3, true),
            new Bed("Twin Bed", "TwinComfort", 280, "Twin", false),
            new Chair("Lounge Chair", "LoungeBrand", 220, false, "Velvet"),
            new Table("Bar Table", "BarBrand", 130, 3, "Round"),
            new Sofa("Sectional Sofa", "SectionalBrand", 700, 5, true),
            new Bed("Loft Bed", "Lofty", 500, "Loft", true),
            new Chair("Swivel Chair", "SwivelBrand", 130, true, "Plastic"),
            new Table("Side Table", "SideBrand", 90, 4, "Rectangle"),
            new Sofa("Sleeper Sofa", "SleeperBrand", 450, 3, true),
            new Bed("Murphy Bed", "MurphyMagic", 600, "Murphy", true),
            new Chair("Visitor Chair", "VisitorBrand", 90, false, "Metal"),
            new Table("Study Table", "StudyBrand", 140, 4, "Square"),
            new Sofa("Vintage Sofa", "VintageBrand", 300, 3, false),
            new Bed("Canopy Bed", "CanopyLuxury", 700, "Canopy", true)
        };

        Console.WriteLine("Распределяем мебель...\n");

        catalogs[0].AddItems(myFurnitures[..20]);
        catalogs[1].AddItems(myFurnitures[20..]);
        catalogs[2].AddItems(myFurnitures[..20]);

        string path = "Catalogs";
        if (!Directory.Exists(path))
        {
            Directory.CreateDirectory(path);
        }

        string raw = "raw_data.json";
        raw = Path.Combine(path, raw);
        MyJsonSerializer f = new MyJsonSerializer();
        f.Write(catalogs, raw);

        Console.WriteLine("Добавляем ещё...\n");

        catalogs[0].AddItems(myFurnitures[20..28]);
        catalogs[1].AddItems(myFurnitures[..8]);
        catalogs[2].AddItems(myFurnitures[28..36]);

        Console.WriteLine("И ещё...\n");

        catalogs[0].AddItems(myFurnitures[28..32]);
        catalogs[1].AddItems(myFurnitures[8..12]);
        catalogs[2].AddItems(myFurnitures[36..]);

        string data = "data.json";
        data = Path.Combine(path, data);
        f.Write(catalogs, data);

        Console.WriteLine("Сортируем по возрастанию цены...\n");

        catalogs[0].Sort();
        catalogs[1].Sort();
        catalogs[2].Sort();

        string sort_data = "sort_data.json";
        sort_data = Path.Combine(path, sort_data);
        f.Write(catalogs, sort_data);

        Console.WriteLine("Выводим данные из raw_data.json...");

        FurnitureCatalog[] f1 = f.Read(raw);
        foreach (FurnitureCatalog i in f1)
        {
            i.DisplayCatalog();
        }

        Console.WriteLine("\nВыводим данные из data.json...");

        FurnitureCatalog[] f2 = f.Read(data);
        foreach (FurnitureCatalog i in f2)
        {
            i.DisplayCatalog();
        }

        Console.WriteLine("\nВыводим данные из sort_data.json...");

        FurnitureCatalog[] f3 = f.Read(sort_data);
        foreach (FurnitureCatalog i in f3)
        {
            i.DisplayCatalog();
        }

        Console.WriteLine("\nДобавляем в каталог ещё по 4 элемента...\n");

        catalogs[0].AddItems(myFurnitures[36..]);
        catalogs[1].AddItems(myFurnitures[12..16]);
        catalogs[2].AddItems(myFurnitures[..4]);

        MyXmlSerializer x = new MyXmlSerializer();

        Console.WriteLine("\nСоздаём табуреты и кресла и добавляем в каталог...\n");

        Stool[] stools = new Stool[] {
            new Stool("ZeroGravityZephyr", "ZenithComfort", 100, true, "NebulaMesh", 4),
            new Stool("QuantumQuasar", "NovaElegance", 120, false, "QuantumPlastic", 3),
            new Stool("NebulaNimbus", "UrbanChic", 90, true, "CosmicBamboo", 3),
            new Stool("NovaNeutron", "LuxeLiving", 110, false, "StellarSteel", 2),
            new Stool("SpaceSerenity", "RetroFusion", 80, true, "LunarLeather", 4)
        };

        Armchair[] armchairs = new Armchair[] {
            new Armchair("ZeroGravityZephyr", "ZenithComfort", 500, true, "NebulaMesh", "Velvet"),
            new Armchair("QuantumQuasar", "NovaElegance", 600, false, "QuantumPlastic", "Leather"),
            new Armchair("NebulaNimbus", "UrbanChic", 450, true, "CosmicBamboo", "Fabric"),
            new Armchair("NovaNeutron", "LuxeLiving", 550, false, "StellarSteel", "Suede"),
            new Armchair("SpaceSerenity", "RetroFusion", 480, true, "LunarLeather", "Silk")
        };

        catalogs[0].AddItems(stools[..1]);
        catalogs[0].AddItems(stools[1..4]);
        catalogs[0].AddItems(stools);
        catalogs[2].AddItems(armchairs[..3]);
        catalogs[2].AddItems(armchairs[3..5]);
        catalogs[2].AddItems(armchairs[..1]);

        string raw_data = "raw_data.xml";
        raw_data = Path.Combine(path, raw_data);
        x.Write(catalogs, raw_data);

        Console.WriteLine("\nСортируем по бренду и названию...\n");

        catalogs[0].PrioritySort();
        catalogs[1].PrioritySort();
        catalogs[2].PrioritySort();

        string xml_data = "data.xml";
        xml_data = Path.Combine(path, xml_data);
        x.Write(catalogs, xml_data);

        Console.WriteLine("Выводим данные из raw_data.xml...");

        FurnitureCatalog[] f4 = x.Read(raw_data);
        foreach (FurnitureCatalog i in f4)
        {
            i.DisplayCatalog();
        }

        Console.WriteLine("\nВыводим данные из data.xml...");

        FurnitureCatalog[] f5 = x.Read(xml_data);
        foreach (FurnitureCatalog i in f5)
        {
            i.DisplayCatalog();
        }
    }
}