﻿class Program
{
    public static void Main()
    {
        Shelter[] shelters = new Shelter[] { new Shelter("Shelter 1", 20, true), new Shelter("Shelter 2", 20, true), new Shelter("Shelter 3", 20, false) };

        Animal[] myAnimals = new Animal[] {
            new Dog("Макс", 63, 69, 12, 5, "лабрадор", "высокий"),
            new Dog("Барон", 62, 70, 10, 3, "овчарка", "средний"),
            new Dog("Чарли", 57, 68, 9, 1, "шнауцер", "средний"),
            new Rabbit("Джек", 39, 34, 2, 1, "серебристый", true),
            new Dog("Бобик", 55, 68, 9, 1, "пудель", "низкий"),
            new Cat("Матроскин", 49, 44, 5, 4, "персидская", true),
            new Dog("Буч", 56, 66, 11, 2, "дог", "высокий"),
            new Dog("Шарик", 58, 66, 11, 4, "колли", "средний"),
            new Cat("Симба", 51, 46, 6, 5, "сфинкс", true),
            new Cat("Том", 48, 43, 5, 4, "британская", true),
            new Cat("Барсик", 47, 42, 4, 3, "ангорская", false),
            new Dog("Рекс", 61, 67, 7, 2, "долматинец", "средний"),
            new Rabbit("Снежок", 44, 39, 4, 2, "калифорнийский", true),
            new Cat("Масяня", 43, 38, 2, 1, "британская", false),
            new Rabbit("Марта", 47, 42, 5, 3, "калифорнийский", false),
            new Rabbit("Вася", 43, 37, 3, 1, "флорида", false),
            new Cat("Лили", 46, 41, 4, 3, "сибирская", true),
            new Dog("Байкал", 64, 70, 10, 4, "хаски", "высокий"),
            new Rabbit("Алиса", 45, 40, 4, 2, "ангора", true),
            new Dog("Рокки", 60, 65, 8, 2, "бигль", "высокий"),
            new Rabbit("Боб", 42, 38, 3, 1, "рекс", false),
            new Rabbit("Джек", 39, 34, 2, 1, "серебристый", true),
            new Dog("Джек", 59, 65, 8, 3, "ретривер", "низкий"),
            new Rabbit("Жора", 46, 41, 4, 2, "рекс", false),
            new Cat("Мурзик", 50, 45, 6, 5, "мейн-кун", false),
            new Rabbit("Максим", 40, 36, 3, 1, "шиншилла", false),
            new Rabbit("Шершень", 38, 33, 2, 1, "рекс", true),
            new Cat("Бусинка", 45, 40, 3, 2, "рыжая", false),
            new Cat("Мурзик", 50, 45, 6, 5, "мейн-кун", false),
            new Cat("Васька", 44, 39, 3, 2, "шотландская", true)
        };


        Console.WriteLine("Распределяем животных...");

        shelters[0].Add(myAnimals[..5]);
        shelters[1].Add(myAnimals[5..10]);
        shelters[2].Add(myAnimals[10..15]);
        myAnimals = myAnimals[15..];

        string path = "Shelters";
        if (!Directory.Exists(path))
        {
            Directory.CreateDirectory(path);
        }
        string raw = "raw_data.json";
        raw = Path.Combine(path, raw);
        MyJsonSerializer f = new MyJsonSerializer();
        if (!File.Exists(raw))
        {
            f.Write(shelters, raw);
        }
        else
        {
            Shelter[] t1 = f.Read(raw);
            foreach (Shelter t2 in t1)
            {
                Console.WriteLine(t2);
            }
        }
        Console.WriteLine("Добавляем ещё...");

        shelters[0].Add(myAnimals[..5]);
        shelters[1].Add(myAnimals[5..10]);
        shelters[2].Add(myAnimals[10..]);

        string data = "data.json";
        data = Path.Combine(path, data);
        if (!File.Exists(data))
        {
            f.Write(shelters, data);
        }
        else
        {
            Shelter[] t1 = f.Read(data);
            foreach (Shelter t2 in t1)
            {
                Console.WriteLine(t2);
            }
        }

        Console.WriteLine("Отдаём новым хозяевам...");

        shelters[0].Remove(shelters[0].Animals[0]);
        shelters[1].Remove(shelters[1].Animals[0]);
        shelters[2].Remove(shelters[2].Animals[0]);

        string new_data = "new_data.json";
        new_data = Path.Combine(path, new_data);
        if (!File.Exists(new_data))
        {
            f.Write(shelters, new_data);
        }
        else
        {
            Shelter[] t1 = f.Read(new_data);
            foreach (Shelter t2 in t1)
            {
                Console.WriteLine(t2);
            }
        }

        //Дополнительная часть 
        MyXmlSerializer x = new MyXmlSerializer();

        Console.WriteLine("Берем 3 самых старших...");
        shelters[0].SortAnimals();
        shelters[1].SortAnimals();
        shelters[2].SortAnimals();

        for (int i = 0; i < 3; i++)
        {
            shelters[0].Remove(shelters[0].Animals[i]);
            shelters[1].Remove(shelters[1].Animals[i]);
            shelters[2].Remove(shelters[2].Animals[i]);
        }

        string raw_data = "raw_data.xml";
        raw_data = Path.Combine(path, raw_data);
        if (!File.Exists(raw_data))
        {
            x.Write(shelters, raw_data);
        }
        else
        {
            Shelter[] t3 = x.Read(raw_data);
            foreach (Shelter t2 in t3)
            {
                Console.WriteLine(t2);
            }
        }

        Console.WriteLine("Помещаем в первый приют по 5 животных каждого вида...");
        Animal[] cats = new Animal[5]
        {
            new Cat("Муся", 42, 37, 3, 2, "сиамская", true),
            new Cat("Мурка", 44, 39, 4, 3, "бенгальская", false),
            new Cat("Феликс", 46, 41, 5, 4, "абиссинская", true),
            new Cat("Багира", 48, 43, 6, 5, "бомбейская", false),
            new Cat("Гарфилд", 50, 45, 7, 6, "экзотическая", true),

        };
        Animal[] dogs = new Animal[5]
        {
            new Dog("Бадди", 57, 60, 9, 3, "бульдог", "средний"),
            new Dog("Тайсон", 65, 72, 11, 4, "ротвейлер", "высокий"),
            new Dog("Сэм", 54, 63, 8, 2, "такса", "низкий"),
            new Dog("Ральф", 60, 68, 10, 5, "боксер", "средний"),
            new Dog("Оскар", 59, 64, 9, 3, "спаниель", "средний")
        };
        Animal[] rabbits = new Animal[5]
        {
            new Rabbit("Ромашка", 40, 36, 3, 1, "бельгийский", true),
            new Rabbit("Пушок", 42, 38, 4, 2, "лиса", false),
            new Rabbit("Беляш", 44, 40, 5, 3, "арлекин", true),
            new Rabbit("Флокс", 46, 42, 6, 4, "французский", false),
            new Rabbit("Лютик", 48, 44, 7, 5, "виенский", true),
        };

        shelters[0].Add(cats);
        shelters[0].Add(dogs);
        shelters[0].Add(rabbits);

        string dataxml = "data.xml";
        dataxml = Path.Combine(path, dataxml);
        if (!File.Exists(dataxml))
        {
            x.Write(shelters, dataxml);
        }
        else
        {
            Shelter[] t4 = x.Read(dataxml);
            foreach (Shelter t2 in t4)
            {
                Console.WriteLine(t2);
            }
        }

    }
}