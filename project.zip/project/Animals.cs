﻿using System.Text.Json.Serialization;
using System.Xml.Serialization;

[Serializable]
public class Animal
{
    [XmlAttribute]
    protected string name;
    [XmlAttribute]
    protected int length;
    [XmlAttribute]
    protected int height;
    [XmlAttribute]
    protected int weight;
    [XmlAttribute]
    protected int age;
    [XmlAttribute]
    protected bool claustrophobia;
    public bool Claustrophobia
    {
        get => claustrophobia;
        set => claustrophobia = value;
    }

    public string Name
    {
        get => name;
        set => name = value;
    }

    public int Length
    {
        get => length;
        set => length = value;
    }

    public int Height
    {
        get => height;
        set => height = value;
    }
    public int Weight
    {
        get => weight;
        set => weight = value;
    }
    public int Age
    {
        get => age;
        set => age = value;
    }

    [JsonConstructor]
    public Animal(string name, int length, int height, int weight, int age)
    {
        this.name = name;
        this.length = length;
        this.height = height;
        this.weight = weight;
        this.age = age;
    }
    public Animal() { }
    public virtual string ToString()
    {
        return "Информация о животном:" + "\n" + $"Имя - {name}" + "\n" + $"Длина - {length}" + "\n" + $"Высота - {height}" + "\n" + $"Вес - {weight}" + "\n" + $"Возраст - {age}" + "\n";
    }
}

[Serializable]
public class Cat : Animal
{
    [XmlAttribute]
    private string breed;
    [XmlAttribute]
    private bool isIndoor;

    public string Breed
    {
        get => breed;
        set => breed = value;
    }

    public bool IsIndoor
    {
        get => isIndoor;
        set => isIndoor = value;
    }


    [JsonConstructor]
    public Cat(string name, int length, int height, int weight, int age, string breed, bool isIndoor) : base(name, length, height, weight, age)
    {
        this.breed = breed;
        this.isIndoor = isIndoor;
    }

    public Cat(string name, int length, int height, int weight, int age, string breed, bool isIndoor, bool claustrophobia) : base(name, length, height, weight, age)
    {
        this.breed = breed;
        this.isIndoor = isIndoor;
        this.claustrophobia = claustrophobia;
    }

    public Cat() { }

    public override string ToString()
    {
        return "Информация о котике:" + "\n" + $"Имя - {name}" + "\n" + $"Длина - {length}" + "\n" + $"Высота - {height}" + "\n" + $"Вес - {weight}" + "\n" + $"Возраст - {age}" + "\n" + $"Порода - {breed}" + "\n" + $"Домашний - {isIndoor}" + "\n";
    }
}
[Serializable]
public class Dog : Animal
{
    [XmlAttribute]
    private string breed;
    [XmlAttribute]
    private string trainingLevel;

    public string Breed
    {
        get => breed;
        set => breed = value;
    }

    public string TrainingLevel
    {
        get => trainingLevel;
        set => trainingLevel = value;
    }


    [JsonConstructor]
    public Dog(string name, int length, int height, int weight, int age, string breed, string trainingLevel) : base(name, length, height, weight, age)
    {
        this.breed = breed;
        this.trainingLevel = trainingLevel;
    }

    public Dog(string name, int length, int height, int weight, int age, string breed, string trainingLevel, bool claustrophobia) : base(name, length, height, weight, age)
    {
        this.breed = breed;
        this.trainingLevel = trainingLevel;
        this.claustrophobia = claustrophobia;
    }

    public Dog() { }

    public override string ToString()
    {
        return "Информация о песике:" + "\n" + $"Имя - {name}" + "\n" + $"Длина - {length}" + "\n" + $"Высота - {height}" + "\n" + $"Вес - {weight}" + "\n" + $"Возраст - {age}" + "\n" + $"Порода - {breed}" + "\n" + $"Уровень подготовки - {trainingLevel}" + "\n";
    }
}
[Serializable]
public class Rabbit : Animal
{
    [XmlAttribute]
    private string furType;
    [XmlAttribute]
    private bool isNeutered;

    public string FurType
    {
        get => furType;
        set => furType = value;
    }

    public bool IsNeutered
    {
        get => isNeutered;
        set => isNeutered = value;
    }


    [JsonConstructor]
    public Rabbit(string name, int length, int height, int weight, int age, string furType, bool isNeutered) : base(name, length, height, weight, age)
    {
        this.furType = furType;
        this.isNeutered = isNeutered;
    }

    public Rabbit(string name, int length, int height, int weight, int age, string furType, bool isNeutered, bool claustrophobia) : base(name, length, height, weight, age)
    {
        this.furType = furType;
        this.isNeutered = isNeutered;
        this.claustrophobia = claustrophobia;
    }

    public Rabbit() { }

    public override string ToString()
    {
        return "Информация о зайчике:" + "\n" + $"Имя - {name}" + "\n" + $"Длина - {length}" + "\n" + $"Высота - {height}" + "\n" + $"Вес - {weight}" + "\n" + $"Возраст - {age}" + "\n" + $"Тип меха - {furType}" + "\n" + $"Кастрированный - {isNeutered}" + "\n";
    }
}

interface ICountable
{
    int Count();
    int Count(string t);
    int Percentage(string t);
}