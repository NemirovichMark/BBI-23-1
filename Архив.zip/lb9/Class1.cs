﻿namespace lb9;

public class Class1
{

}

